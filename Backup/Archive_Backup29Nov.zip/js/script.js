
var w = 1200;
var h = 1200;
var svgPadding = 50;
var spacing = 5;
var iconDim = 80;
var targetYPosition = 2*svgPadding + iconDim;
var targetTextHeight = 20;

var graphYPos;
var graphFixedWidth = 500;
var graphFixedHeight = 250;

var targetData, profileData, targetDimension, indicatorDimension, regionDimension;

d3.queue().defer(d3.csv, "TargetList.csv")
    .defer(d3.csv, "IndicatorProfiles.csv")
    .await(instantiatePageDefaults);

function instantiatePageDefaults(error, targets, profiles)
{
    targetData = targets;
    profileData = crossfilter(profiles);
    goalDimension = profileData.dimension(function(d) { return d.GoalID; });
    targetDimension = profileData.dimension(function(d) { return String(d.TargetID); });
    indicatorDimension = profileData.dimension(function(d) { return d.Indicator; });
    regionDimension = profileData.dimension(function(d) { return d.Region; });

    clearAllFilters();

    renderTargetList(1);
    //renderDataAvailability("1.1");
};


function renderTargetList(goalID) {

    d3.selectAll(".img").classed("selected", false);

    var thisDiv = "goal" + String(goalID);

    addRemoveClass(thisDiv, "selected", "add");
    
    d3.select("body").selectAll(".targets").remove();
    d3.select("body").selectAll(".indicators").remove();

    var targetsDiv = d3.select("div.container").append("div").classed("targets", true).classed("row", true);

    targetsDiv.selectAll("p")
        .data(targetData)
        .enter()
        .append("p")
        .classed("toRemove", true)
        .filter(function(d) { return d.GoalID == goalID; })
        .text(function(d) { return d.TargetID + " - " + d.TargetDesc; })
        .attr("onclick", function(d) { return "renderDataAvailability('" + String(d.TargetID) + "')"; })
        .attr("id", function(d) { return "target" + String(d.TargetID); })
        .classed("goal" + goalID, true)
        .classed("targets", true)
        .classed("toRemove", false);     

        d3.selectAll("p.toRemove").remove();


    clearAllFilters();
    goalDimension.filter(String(goalID));
    var targetIDs = targetDimension.group().all();
    for(var i = 0; i<targetIDs.length; i++)
    {
        if(targetIDs[i].value > 0)
            break;
    }
    renderDataAvailability(String(targetIDs[i].key));


};

function clearAllFilters() {

    goalDimension.filterAll();
    targetDimension.filterAll();
    indicatorDimension.filterAll();
    regionDimension.filterAll();

}

function addRemoveClass(id, className, operation) {
    
    var elem = document.getElementById(id);

    if(operation == "add")
    {   
        elem.classList.add(className);
    }
    else
    {
        elem.classList.remove(className);
    }

}

function renderDataAvailability(targetID) {
    d3.selectAll("p.targets").classed("selected", false);

    var thisPara = "target" + String(targetID);

    addRemoveClass(thisPara, "selected", "add");

    d3.selectAll(".indicators").remove();

    var indicatorDiv = d3.select("div.container").append("div").classed("indicators", true).classed("row",true);

    clearAllFilters();
    targetDimension.filter(String(targetID));

    var indicatorGrouping = indicatorDimension.group().all();

    var indicatorCount = 0;

    var indicatorTexts = [];

    for(var i = 0 ; i<indicatorGrouping.length; i++)
        {
            if(indicatorGrouping[i].value > 0)
            {                   
                indicatorTexts[indicatorCount] = indicatorGrouping[i].key;
                indicatorCount++;
            }
        }

    for(var i = 0; i < indicatorCount; i++)
    {
        //filter out data for only this indicator
        indicatorDimension.filterAll();

        var indicatorFilter = indicatorDimension.filter(indicatorTexts[i]);

        var regionMeasure = regionDimension.group().reduceCount().all();

        var regionCount = countMyGroup(regionMeasure);

        var barXScale = d3.scale.ordinal()
                        .domain(d3.range(regionCount))
                        .rangeRoundBands([svgPadding, graphFixedWidth], 0.1);

        var barYScale = d3.scale.linear()
                        .domain([0, 100])
                        .range([0, graphFixedHeight - svgPadding]);

        var thisSvg = indicatorDiv.append("svg")
            .attr({
                width: graphFixedWidth + svgPadding,
                height: graphFixedHeight + 2*svgPadding
            });                        

        //draw graph with dimple.js
        //var barSvg = dimple.newSvg("#indGroup" + i, graphFixedWidth - svgPadding * 2.8, graphFixedHeight - svgPadding);
        var graphData = indicatorFilter.top(Infinity);
        var chart = new dimple.chart(thisSvg, graphData);
        chart.setBounds(svgPadding,svgPadding, graphFixedWidth - svgPadding, graphFixedHeight - svgPadding);
        var xAxis = chart.addCategoryAxis("x", "Region");
        
        var yAxis = chart.addMeasureAxis("y", "Ratio");
        yAxis.ticks = 5;
        yAxis.tickFormat = "%";
        
        var mySeries = chart.addSeries(null, dimple.plot.bar);
        mySeries.aggregate = dimple.aggregateMethod.max; 
        xAxis.addOrderRule("RatioPercent", true);
        //chart.addLegend(60, 10 + barYStart, graphFixedWidth - svgPadding * 1.8, svgPadding, "right");
        chart.draw();

        xAxis.titleShape.remove();
        yAxis.titleShape.remove();


        xAxis.shapes.selectAll("text").attr("transform", 
            function(d) {
                return d3.select(this).attr("transform") + " translate(0, 20) rotate(-45)";
            });

        thisSvg.append("text")
            .attr({
                x: chart._xPixels(),
                y: chart._yPixels() - 20,
                fill: "grey"
            })
            //.style("text-anchor", "middle")
            .text("Data Availability for " + indicatorTexts[i]);

    }
};

var countMyGroup = function(groupToClean) {

        var cleanCount = 0;

        for(var i=0 ; i<groupToClean.length; i++)
            {
                if(groupToClean[i].value > 0)
                {   
                    cleanCount++;
                }
            }
        return cleanCount;   

    }



