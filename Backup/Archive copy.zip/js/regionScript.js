
d3.queue().defer(d3.csv, "TargetList.csv")
    .defer(d3.csv, "IndicatorProfiles.csv")
    .await(instantiatePageDefaults);

document.addEventListener("onload",loadSVG(),false)

function loadSVG()
{
    var SVGFile="world.svg"
    var loadXML = new XMLHttpRequest;
    function handler()
    {
        if(loadXML.readyState == 4)
        {
            if (loadXML.status == 200) //---loaded ok---
            {
                //---responseText---
                var mySVGDiv = document.getElementById("svgDiv");
                var xmlString=loadXML.responseText;
                mySVGDiv.innerHTML=xmlString;
            }
        }
    }
    if (loadXML != null)
    {
        loadXML.open("GET", SVGFile, true);
        loadXML.onreadystatechange = handler;
        loadXML.send();
    }
}

function renderCountryList(regionName) {
    console.log(regionName);
    d3.csv("RefAreaGrid.csv", function(data) {
        var countryListDiv = d3.select("#countryListDiv");

        countryListDiv.selectAll("button")
            .data(data)
            .enter().append("button")
            .classed("toRemove", true)
            .filter(function(d) { return d.ParentCode == regionName; })
            .classed("btn btn-secondary", true)
            .text(function(d) { return d.AreaName; })
            .attr("onclick", function(d){ return "renderSeriesGrid(" + d.AreaCode + ")" });

        d3.selectAll(".toRemove").remove();

    });
}