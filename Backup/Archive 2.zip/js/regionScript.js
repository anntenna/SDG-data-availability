
d3.queue().defer(d3.csv, "RefAreaGrid.csv")
    .defer(d3.csv, "CountryProfiles.csv")
    .defer(d3.json, "SeriesTree.json")
    .await(instantiatePageDefaults);

document.addEventListener("onload",loadSVG(),false)

var defaultRegionCode = "CAU_CEN_ASIA";
var defaultCountryCode = "ARM";
var regionData, countryData, seriesData;

function loadSVG()
{
    var SVGFile="world.svg"
    var loadXML = new XMLHttpRequest;
    function handler()
    {
        if(loadXML.readyState == 4)
        {
            if (loadXML.status == 200) //---loaded ok---
            {
                //---responseText---
                var mySVGDiv = document.getElementById("svgDiv");
                var xmlString=loadXML.responseText;
                mySVGDiv.innerHTML=xmlString;
            }
        }
    }
    if (loadXML != null)
    {
        loadXML.open("GET", SVGFile, true);
        loadXML.onreadystatechange = handler;
        loadXML.send();
    }
}

function instantiatePageDefaults(error, RegionGrid, CountryProfiles, SeriesTree) {
    if(error) {
        d3.select("div.container").append("p").text("Error loading data: " + error);
    }
    else {
        seriesData = SeriesTree;
        regionData = RegionGrid;
        countryData = crossfilter(CountryProfiles);

        renderCountryList(defaultRegionCode);
    }
}

function renderCountryList(regionName) {
    console.log(regionName);
        var countryListDiv = d3.select("#countryListDiv");

    d3.selectAll(".countryLink").remove();

    countryListDiv.selectAll("a")
        .data(regionData)
        .enter().append("a")
        .classed("toRemove", true)
        .filter(function(d) { return d.ParentCode == regionName; })
        .classed("countryLink btn btn-outline-primary btn-sm", true)
        .classed("toRemove", false)
        .text(function(d) { return d.AreaName; })
        .attr("href", function(d){ return "javascript:renderSeriesTrees('" + d.AreaCode + "')" })
        .attr("role", "button");

    d3.selectAll(".toRemove").remove();

    renderSeriesTrees(defaultCountryCode);

}

function renderSeriesTrees(countryCode) {

   var dataMap = seriesData.reduce(function(map, node) {
        map[node.name] = node;
        return map;
    }, {});

    var treeData = [];
    seriesData.forEach(function(node) {
        // add to parent
        var parent = dataMap[node.parent];
        if (parent) {
        // create child array if it doesn't exist
            (parent.children || (parent.children = []))
            // add node to child array
                .push(node);
        } 
        else {
            // parent is null or missing
            treeData.push(node);
        }
    });

    for(var i = 0; i < treeData.length; i++) {
         drawSeriesTree(treeData[i]);
    } 

}

function add(a, b) {
    return a + b;
}

function drawSeriesTree(source) {

   var margin = {top: 10, right: 20, bottom: 10, left: 15};
   var nodeHeight = 15,
       iconDim = 60,
       nodeWidthbyDepth = [60, 30, 50, 100];
       verticalPadding = 5,
       horizontalPadding = 12;
       nodeClassbyDepth = ["goal", "target", "indicator", "series"],
       negative = -1;
       treeFactor = 0.5;

   var tree = d3.layout.tree();

   var nodes = tree.nodes(source),
          links = tree.links(nodes);

   var numChildren = nodes.length - 1;

   var treeWidth = nodeWidthbyDepth.reduce(add, 0) * treeFactor;
   var treeHeight = iconDim + numChildren * (nodeHeight + verticalPadding);

   tree.size([treeHeight, treeWidth]); 

   nodes = tree.nodes(source).reverse();
   links = tree.links(nodes);

   var line = d3.svg.line()
                 .x( function(point) { return point.lx; })
                 .y( function(point) { return point.ly; })
                 .interpolate("step-before");

   function lineData(d){
       // i'm assuming here that supplied datum 
       // is a link between 'source' and 'target'
       var points = [
           {lx: d.source.y, ly: d.source.x},
           {lx: d.target.y, ly: d.target.x}
       ];
       return line(points);
   }


   var diagonal = d3.svg.diagonal()
        .projection(function(d) { return [d.y, d.x]; });

    var svg = d3.select("#treeDiv").append("svg")
        .attr("width", treeWidth + margin.right + margin.left)
        .attr("height", treeHeight + margin.top + margin.bottom)
        .append("g")
        .attr("transform", "translate(" + margin.left + "," + margin.top + ")");

   for(var i = 0; i < nodes.length; i++) { 

      thisNode = nodes[i];
      thisNodeID = i + 1;

      if(thisNode.type == "Goal") {
         thisNode.x = verticalPadding;
         thisNode.y = verticalPadding;
      }
      else {
         thisNode.x = iconDim + nodeHeight + verticalPadding + (numChildren - thisNodeID) * (verticalPadding + nodeHeight);
         thisNode.y = thisNode.depth * horizontalPadding + treeFactor * nodeWidthbyDepth[thisNode.depth];
      }
   }


   var i = 0;

   var node = svg.selectAll("g.node")
          .data(nodes, function(d) { return d.id || (d.id = ++i); });

   var nodeEnter = node.enter().append("g")
      .attr("class", "node")
      .attr("transform", function(d) { 
       return "translate(" + d.y + "," + d.x + ")"; });

   nodeEnter.filter(function(d) { return d.type == "Goal";})
       .append("image")
       .attr({
         x: negative * verticalPadding,
         y: negative * verticalPadding,
         width: iconDim,
         height: iconDim,
         "xlink:href": function(d){ return "img/" + d.name + ".svg"; }
       })
       .classed("goal", true);

   nodeEnter.filter(function(d) { return d.type == "Target";})
       .append("rect")
       .attr({
         x: function(d) { return negative * treeFactor * nodeWidthbyDepth[d.depth]; },
         y: negative * treeFactor * nodeHeight,
         width: function(d) { return nodeWidthbyDepth[d.depth]; },
         height: nodeHeight
       })
       .style("fill", "#fff")
       .classed("target", true);

   nodeEnter.filter(function(d) { return d.type == "Indicator";})
       .append("rect")
       .attr({
         x: function(d) { return negative * treeFactor * nodeWidthbyDepth[d.depth]; },
         y: negative * treeFactor * nodeHeight,
         width: function(d) { return nodeWidthbyDepth[d.depth]; },
         height: nodeHeight
       })
       .style("fill", "#fff")
       .classed("indicator", true);

   nodeEnter.filter(function(d) { return d.type == "Series";})
       .append("rect")
       .attr({
         x: function(d) { return negative * treeFactor * nodeWidthbyDepth[d.depth]; },
         y: negative * treeFactor * nodeHeight,
         width: function(d) { return nodeWidthbyDepth[d.depth]; },
         height: nodeHeight
       })
       .style("fill", "#fff")
       .classed("series", true);

   nodeEnter.filter(function(d) { return d.type != "Goal";})
       .append("text")
      .attr("y", 0)
      .attr("dy", ".35em")
      .attr("text-anchor", "middle")
      .text(function(d) { return d.name; })
      .style("fill-opacity", 1);

   // Declare the links
    var link = svg.selectAll("path.link")
       .data(links, function(d) { return d.target.id; });

   // Enter the links.
   link.enter().insert("path", "g")
    .attr("class", "link")
    .attr("d", lineData);

}
