
document.addEventListener("onload",loadSVG(),false)


var defaultRegionCode = "CAU_CEN_ASIA";
var regionData, countryData, seriesData, mapSVG;

function loadSVG()
{
    var SVGFile="world.svg"
    var loadXML = new XMLHttpRequest;
    function handler()
    {
        if(loadXML.readyState == 4)
        {
            if (loadXML.status == 200) //---loaded ok---
            {
                //---responseText---
                var mySVGDiv = document.getElementById("svgDiv");
                var xmlString=loadXML.responseText;
                mySVGDiv.innerHTML=xmlString;
                console.log("map is done");

                d3.queue().defer(d3.csv, "RefAreaGrid.csv")
                   .defer(d3.csv, "CountryProfiles.csv")
                   .defer(d3.json, "SeriesTree.json")
                   .await(instantiatePageDefaults);
            }
        }
    }
    if (loadXML != null)
    {
        loadXML.open("GET", SVGFile, true);
        loadXML.onreadystatechange = handler;
        loadXML.send();
    }
}

function instantiatePageDefaults(error, RegionGrid, CountryProfiles, SeriesTree) {
    if(error) {
        d3.select("div.container").append("p").text("Error loading data: " + error);
    }
    else {
        seriesData = SeriesTree;
        regionData = RegionGrid;
        countryData = crossfilter(CountryProfiles);
        areaCodeDimension = countryData.dimension(function(d) { return d.AreaCode; });
        typeDimension = countryData.dimension(function(d) { return d.Type; });
        //nameDimension = countryData.dimension(function(d) { return d.Name; });
        mapSVG = d3.select("#world");

        renderSeriesTrees();

        renderCountryList(defaultRegionCode);
    }
}

function renderCountryList(regionName) {

   mapSVG.selectAll("g").classed("selected", false);
   d3.selectAll("g.node image").attr("xlink:href",function(d){ return "img/Inverted_" + d.name + ".svg"; });

   mapSVG.select("g#" + regionName).classed("selected", true);

   d3.selectAll("text.country").remove();
   d3.select("rect.country").remove();

   d3.select("#marker").attr("transform", "translate(-50,-50)");

   console.log(regionName);
   var countryListDiv = d3.select("#countryListDiv");

   d3.selectAll(".countryLink").remove();

   countryListDiv.selectAll("a")
      .data(regionData)
      .enter().append("a")
      .classed("toRemove", true)
      .filter(function(d) { return d.ParentCode == regionName; })
      .classed("countryLink btn btn-outline-primary btn-sm", true)
      .classed("toRemove", false)
      .text(function(d) { return d.AreaName; })
      .attr("href", function(d){ return "javascript:renderDataAvailability('" + d.AreaCode + "')" })
      .attr("role", "button");

   d3.selectAll(".toRemove").remove();

   renderDataAvailability(regionData.filter(function(d) { return d.ParentCode == regionName; })[0].AreaCode);

}

function getBoundingBox(selection) {
   var element = selection.node();
        // use the native SVG interface to get the bounding box
        return element.getBBox();
}

function renderDataAvailability(countryCode) {

   //Manage visual changes

   //Remove previous selection visual elements - Country map marker
   d3.select("text.country").remove();
   d3.select("rect.country").remove();
   d3.selectAll("g.node image").attr("xlink:href",function(d){ return "img/Inverted_" + d.name + ".svg"; });


   //Get elements for marker and country.
   var pathSelection = d3.select("path#" + countryCode);
   var markerSelection = d3.select("#marker");

   //Get country data
   var countryDetails = regionData.filter(function(d) { return d.AreaCode == countryCode })[0];

   //Get bounding boxes for marker and country from the elements to calculate locations to place the rest of the map marker.
   var countryBBox = getBoundingBox(pathSelection);
   var markerBBox = getBoundingBox(markerSelection);

   //Set location of marker
   var markerX = countryBBox.x + countryBBox.width/2 - markerBBox.width/2;
   var markerY = countryBBox.y + countryBBox.height/2 - markerBBox.height;
   markerSelection.attr("transform", "translate(" + markerX + "," + markerY + ")");

   //Set location of text and enclosing rect element.
   var textX = markerX;
   var textY = countryBBox.y + countryBBox.height/2 + 35;
   var countryText = d3.select("#world").append("text")
      .attr("x", textX)
      .attr("y", textY)
      .text(countryDetails.AreaName)
      .classed("country", true);

   var countryTextBBox = getBoundingBox(countryText);
   d3.select("#world").insert("rect", "text")
      .attr({
         x: countryTextBBox.x - 15,
         y: countryTextBBox.y - 5,
         width: countryTextBBox.width + 30,
         height: countryTextBBox.height + 10,
         fill: "#fff",
         "fill-opacity": 0.8,
         rx: 10,
         ry: 10
      })
      .classed("country", true);

   d3.selectAll("g.node").classed("full", false);
   d3.selectAll("g.node").classed("partial", false);
   d3.selectAll("g.node").classed("none", false);

   //End visual element generation
   //Begin data analysis
   var classAssignments = ["none", "partial", "full"]

   areaCodeDimension.filter(String(countryCode));
   //var seriesFilter = typeDimension.filter("Series");
   var thisAreaData = areaCodeDimension.top(Infinity);

   for(var i = 0; i < thisAreaData.length; i++) {
      var thisNode = d3.select("[name = '" + thisAreaData[i].Type + thisAreaData[i].Name + replaceIfNullOrEmpty(thisAreaData[i].ParentType) + replaceIfNullOrEmpty(thisAreaData[i].ParentName) + "']");
      var classToBeAssigned = classAssignments[thisAreaData[i].NumDataPoints];
      thisNode.classed(classToBeAssigned, true);
   }

   d3.selectAll("g.full image").attr("xlink:href",function(d){ return "img/" + d.name + ".svg"; });
   d3.selectAll("g.node:not(.full):not(.partial) image").attr("xlink:href", function(d) { return "img/Grey_" + d.name + ".svg"; });


}




function renderSeriesTrees() {

   var dataMap = seriesData.reduce(function(map, node) {
        map[node.name] = node;
        return map;
    }, {});

    var treeData = [];
    seriesData.forEach(function(node) {
        // add to parent
        var parent = dataMap[node.parent];
        if (parent) {
        // create child array if it doesn't exist
            (parent.children || (parent.children = []))
            // add node to child array
                .push(node);
        } 
        else {
            // parent is null or missing
            treeData.push(node);
        }
    });

    for(var i = 0; i < treeData.length; i++) {
         drawSeriesTree(treeData[i]);
    } 

}

function add(a, b) {
    return a + b;
}

function replaceIfNullOrEmpty(obj) {
  if(obj) {
    return obj;
  }
  else {
    return "";
  }
}

function drawSeriesTree(source) {

   var margin = {top: 10, right: 17, bottom: 10, left: 5};
   var nodeHeight = 15,
       iconDim = 60,
       nodeWidthbyDepth = [60, 22, 30, 90];
       verticalPadding = 5,
       horizontalPadding = 9,
       negative = -1,
       treeFactor = 0.5,
       goalNum = "goal" + source.name;

   var tree = d3.layout.tree();

   var nodes = tree.nodes(source),
          links = tree.links(nodes);

   var numChildren = nodes.length - 1;

   var treeWidth = nodeWidthbyDepth.reduce(add, 0) * treeFactor;
   var treeHeight = iconDim + numChildren * (nodeHeight + verticalPadding);

   tree.size([treeHeight, treeWidth]); 

   nodes = tree.nodes(source).reverse();
   links = tree.links(nodes);

   var line = d3.svg.line()
                 .x( function(point) { return point.lx; })
                 .y( function(point) { return point.ly; })
                 .interpolate("step-before");

   function lineData(d){
       // i'm assuming here that supplied datum 
       // is a link between 'source' and 'target'
       var points = [
           {lx: d.source.y, ly: d.source.x},
           {lx: d.target.y, ly: d.target.x}
       ];
       return line(points);
   }

   var svg = d3.select("#treeDiv").append("svg")
        .attr("width", treeWidth + margin.right + margin.left)
        .attr("height", treeHeight + margin.top + margin.bottom)
        .append("g")
        .attr("transform", "translate(" + margin.left + "," + margin.top + ")")
        .classed(goalNum, true);

   for(var i = 0; i < nodes.length; i++) { 

      thisNode = nodes[i];
      thisNodeID = i + 1;

      if(thisNode.type == "Goal") {
         thisNode.x = verticalPadding;
         thisNode.y = verticalPadding;
      }
      else {
         thisNode.x = iconDim + nodeHeight + verticalPadding + (numChildren - thisNodeID) * (verticalPadding + nodeHeight);
         thisNode.y = thisNode.depth * horizontalPadding + treeFactor * nodeWidthbyDepth[thisNode.depth];
      }
   }

   var i = 0;

   var node = svg.selectAll("g.node")
          .data(nodes, function(d) { return d.id || (d.id = ++i); });

   var nodeEnter = node.enter().append("g")
      .attr("name", function(d) { return d.type + d.name + replaceIfNullOrEmpty(d.parent.type) + replaceIfNullOrEmpty(d.parent.name); })
      .attr("class", "node")
      .attr("transform", function(d) { 
       return "translate(" + d.y + "," + d.x + ")"; });


   nodeEnter.filter(function(d) { return d.type == "Goal";})
       .append("image")
       .attr({
         x: negative * verticalPadding,
         y: negative * verticalPadding,
         width: iconDim,
         height: iconDim,
         "xlink:href": function(d){ return "img/Inverted_" + d.name + ".svg"; }
       });

   nodeEnter.filter(function(d) { return d.type == "Goal"})
      .append("rect")
       .attr({
         x: negative * verticalPadding,
         y: negative * verticalPadding,
         width: iconDim,
         height: iconDim,
         "fill-opacity": 0
       })
       
   nodeEnter.filter(function(d) { return d.type == "Target";})
       .append("rect")
       .attr({
         x: function(d) { return negative * treeFactor * nodeWidthbyDepth[d.depth]; },
         y: negative * treeFactor * nodeHeight,
         width: function(d) { return nodeWidthbyDepth[d.depth]; },
         height: nodeHeight
       })
       .classed("target", true);

   nodeEnter.filter(function(d) { return d.type == "Indicator";})
       .append("rect")
       .attr({
         x: function(d) { return negative * treeFactor * nodeWidthbyDepth[d.depth]; },
         y: negative * treeFactor * nodeHeight,
         width: function(d) { return nodeWidthbyDepth[d.depth]; },
         height: nodeHeight
       })
       .classed("indicator", true);

   nodeEnter.filter(function(d) { return d.type == "Series";})
       .append("rect")
       .attr({
         x: function(d) { return negative * treeFactor * nodeWidthbyDepth[d.depth]; },
         y: negative * treeFactor * nodeHeight,
         width: function(d) { return nodeWidthbyDepth[d.depth]; },
         height: nodeHeight
       })
       .classed("series", true);

   nodeEnter.filter(function(d) { return d.type != "Goal";})
       .append("text")
      .attr("y", 0)
      .attr("dy", ".35em")
      .attr("text-anchor", "middle")
      .text(function(d) { return d.name; })
      .style("fill-opacity", 1);

   // Declare the links
    var link = svg.selectAll("path.link")
       .data(links, function(d) { return d.target.id; });

   // Enter the links.
   link.enter().insert("path", "g")
    .attr("class", "link")
    .attr("d", lineData);

}
